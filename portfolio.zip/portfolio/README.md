# Liquid Glass Portfolio

A single-page 3D freelancer portfolio: liquid-glass UI, lazy-loaded WebGL hero, eye-tracking cursor,
scroll animations, and a mobile-first layout.

**Stack:** React 18 · Vite · TypeScript · Tailwind CSS 3 · Three.js / React Three Fiber · Framer Motion · Lucide

---

## 1. Run it

Requires Node.js 18+.

```bash
npm install
npm run dev        # http://localhost:5173 (also reachable on your phone via the Network URL)
```

Check everything compiles before you deploy:

```bash
npm run build      # type-checks, then builds to ./dist
npm run preview    # serve the production build locally
```

## 2. Make it yours (one file)

Open **`src/data/content.ts`**. Everything on the page comes from it:

| What | Where |
| --- | --- |
| Your name, role, availability badge | `site.name`, `site.role`, `site.availability` |
| Contact email | `site.email` (empty by default, so the email buttons stay inactive until you set it) |
| Social links | `site.socials[].href` (empty = greyed-out placeholder) |
| About text | `site.about` |
| Services | `services` |
| Projects | `projects` |

All projects ship marked **"Demo project"** with generated artwork. To use real work, edit a project and add:

```ts
image: { src: '/projects/my-work.webp', alt: 'What it shows', width: 1200, height: 900 },
href: 'https://link-to-the-case-study',
```

Put images in `public/projects/` and export them as **WebP or AVIF**. They are lazy-loaded with fixed
dimensions, so there is no layout shift. Remove the "Demo project" badge text in
`src/components/ProjectCard.tsx` once the work is real.

Colors live in `tailwind.config.js` (`electric`, `violet`, `aqua`, `blush`) and the glass look in `src/index.css`.

## 3. Deploy (free, no local tools needed)

Push the project to a GitHub repository, then connect it to any of these. All auto-detect Vite:

| Host | Settings |
| --- | --- |
| **Vercel** | Import repo → Framework: Vite → Deploy |
| **Netlify** | Add new site → Import from Git → Build `npm run build`, Publish `dist` |
| **Cloudflare Pages** | Create project → Connect to Git → Build `npm run build`, Output `dist` |

Or drag-and-drop: run `npm run build` and upload the `dist` folder to Netlify Drop.

**GitHub Pages:** build is already path-relative (`base: './'`). Upload the contents of `dist` to a
`gh-pages` branch, or use a Pages deploy action.

## 4. Working from a phone

1. Create an empty GitHub repo in the browser, then use **Add file → Upload files** to upload the unzipped project.
2. Connect the repo to Vercel / Netlify / Cloudflare Pages (above). Every commit redeploys automatically.
3. To edit content, open `src/data/content.ts` on github.com (pencil icon), change the text, commit. Done.
4. For bigger changes, open the repo in **GitHub Codespaces** from your phone's browser to get a full editor and terminal.

## 5. How it stays fast

- **3D is lazy**: `three` + React Three Fiber are a separate chunk, loaded only after first paint when the browser is idle.
- **Light scene**: one custom shader (fresnel + fake refraction + specular), no textures/models/HDRI, no transmission pass.
- **Render loop is controlled**: pauses when the hero scrolls off-screen, runs on demand only under reduced motion, DPR capped (1.25 on phones, 1.75 desktop), reduced geometry on low-power devices.
- **CSS fallback orb** shows while 3D loads and permanently if WebGL is unavailable, Data Saver is on, or the GPU context is lost.
- **Backdrop blur is restrained**: used on the nav and a few cards only; large/tilting surfaces use a blur-free glass style.
- **Pointer work never re-renders React**: cursor, tilt and parallax run on motion values and refs.
- **Zero image downloads by default**; one self-hosted variable font; no external requests at runtime.

## 6. Accessibility and motion

- `prefers-reduced-motion`: no parallax, tilt, floating, blinking, or smooth scrolling; 3D renders a single static frame.
- The eye cursor shows only for mouse/trackpad (`hover: hover` and `pointer: fine`), never on touch. The native pointer stays visible and keyboard focus rings are untouched.
- Touch devices get tap feedback instead: buttons and cards press in, and the hero object pulses on tap.
- Skip link, semantic landmarks, `aria-current` on the active nav item, 44px+ touch targets, bottom thumb-reach nav on phones.

## 7. Project layout

```
src/
  data/content.ts        ← edit your content here
  components/
    Hero.tsx             hero layout, lazy 3D mounting, CSS orb fallback
    HeroScene.tsx        the WebGL liquid-glass object (lazy chunk)
    EyeCursor.tsx        spring-driven eye cursor
    Nav.tsx              floating glass nav (top on desktop, dock on mobile)
    Services.tsx / Projects.tsx / ProjectCard.tsx / ProjectVisual.tsx / About.tsx / Contact.tsx
    Reveal.tsx           scroll reveal + word-by-word text reveal
  hooks/ lib/            media queries, device checks, smooth-scroll helper
```

## Troubleshooting

- **Blank 3D area, orb only:** WebGL is unavailable or Data Saver is on. That is the intended fallback.
- **`npm run build` type errors:** run `npm install` again to make sure versions in `package.json` were installed, then re-run.
- **Want the 3D object elsewhere:** edit `position`/`scale` near the top of the `Scene` component in `HeroScene.tsx`.
