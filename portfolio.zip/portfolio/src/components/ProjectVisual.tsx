import { Heart, MessageCircle, Play, Send } from 'lucide-react'
import { useId } from 'react'
import type { Project } from '../data/content'

/**
 * Generated artwork for demo projects: pure CSS/SVG, zero image downloads.
 * Real work can override it by setting `image` on a project in data/content.ts.
 */
export default function ProjectVisual({ project }: { project: Project }) {
  const { kind, from, to, image } = project

  if (image) {
    return (
      <img
        src={image.src}
        alt={image.alt}
        width={image.width}
        height={image.height}
        loading="lazy"
        decoding="async"
        className="absolute inset-0 size-full object-cover"
      />
    )
  }

  return (
    <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, ${from}, ${to})` }} aria-hidden="true">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_28%_18%,rgba(255,255,255,0.4),transparent_46%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_85%_100%,rgba(0,0,0,0.45),transparent_55%)]" />
      {kind === 'video' ? <VideoArt /> : null}
      {kind === 'web' ? <WebArt /> : null}
      {kind === 'logo' ? <LogoArt /> : null}
      {kind === 'social' ? <SocialArt /> : null}
    </div>
  )
}

function VideoArt() {
  return (
    <>
      <div className="absolute left-1/2 top-[42%] grid size-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-white/40 bg-white/20 shadow-[0_8px_30px_rgba(0,0,0,0.3)]">
        <Play className="ml-0.5 size-6 fill-white text-white" />
      </div>
      {/* editing timeline */}
      <div className="absolute inset-x-5 bottom-5 space-y-1.5">
        <div className="flex h-2 gap-1">
          {[26, 12, 20, 8, 28].map((w, i) => (
            <span key={i} className="rounded-full bg-white/55" style={{ flexBasis: `${w}%` }} />
          ))}
        </div>
        <div className="flex h-1.5 gap-1">
          {[14, 30, 10, 24, 14].map((w, i) => (
            <span key={i} className="rounded-full bg-white/30" style={{ flexBasis: `${w}%` }} />
          ))}
        </div>
        <span className="absolute -top-1 left-[38%] h-[1.15rem] w-0.5 rounded-full bg-white shadow-[0_0_8px_#fff]" />
      </div>
    </>
  )
}

function WebArt() {
  return (
    <div className="absolute inset-x-6 bottom-0 top-9 overflow-hidden rounded-t-2xl border border-b-0 border-white/30 bg-black/35 shadow-[0_-10px_40px_rgba(0,0,0,0.25)]">
      <div className="flex items-center gap-1.5 border-b border-white/15 px-3 py-2.5">
        <span className="size-2 rounded-full bg-white/50" />
        <span className="size-2 rounded-full bg-white/35" />
        <span className="size-2 rounded-full bg-white/25" />
        <span className="ml-3 h-2 flex-1 rounded-full bg-white/15" />
      </div>
      <div className="space-y-3 p-4">
        <div className="h-3.5 w-3/5 rounded-full bg-white/70" />
        <div className="h-2 w-4/5 rounded-full bg-white/30" />
        <div className="h-2 w-2/5 rounded-full bg-white/30" />
        <div className="h-7 w-24 rounded-full bg-white/80" />
        <div className="grid grid-cols-3 gap-2 pt-2">
          <div className="aspect-[4/3] rounded-lg bg-white/25" />
          <div className="aspect-[4/3] rounded-lg bg-white/15" />
          <div className="aspect-[4/3] rounded-lg bg-white/25" />
        </div>
      </div>
    </div>
  )
}

function LogoArt() {
  const gid = useId()
  return (
    <div className="absolute inset-0 grid place-items-center">
      <svg viewBox="0 0 120 120" className="size-32 drop-shadow-[0_10px_30px_rgba(0,0,0,0.35)]">
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset="1" stopColor="#ffffff" stopOpacity="0.55" />
          </linearGradient>
        </defs>
        <circle cx="60" cy="60" r="34" fill="none" stroke={`url(#${gid})`} strokeWidth="10" />
        <circle cx="86" cy="34" r="12" fill="#fff" />
        <path d="M30 78 Q60 100 90 78" fill="none" stroke="#fff" strokeOpacity="0.7" strokeWidth="5" strokeLinecap="round" />
      </svg>
    </div>
  )
}

function SocialArt() {
  return (
    <div className="absolute inset-0 grid place-items-center">
      <div className="grid w-[72%] max-w-[16rem] grid-cols-3 gap-2">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className={`aspect-square rounded-xl border border-white/25 ${
              i === 1 || i === 4 ? 'bg-white/45' : 'bg-white/20'
            }`}
          />
        ))}
      </div>
      <div className="absolute bottom-5 flex items-center gap-3 rounded-full border border-white/30 bg-black/30 px-4 py-2 text-white">
        <Heart className="size-4" />
        <MessageCircle className="size-4" />
        <Send className="size-4" />
      </div>
    </div>
  )
}
