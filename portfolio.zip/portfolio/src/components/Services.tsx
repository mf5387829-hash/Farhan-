import { motion } from 'framer-motion'
import { Clapperboard, Code2, Shapes, Share2, type LucideIcon } from 'lucide-react'
import type { CSSProperties } from 'react'
import { services, type ServiceIcon } from '../data/content'
import { Reveal } from './Reveal'
import SectionHeader from './SectionHeader'

const icons: Record<ServiceIcon, LucideIcon> = {
  video: Clapperboard,
  web: Code2,
  brand: Shapes,
  social: Share2,
}

export default function Services() {
  return (
    <section id="services" aria-labelledby="services-title" className="relative px-6 py-28 md:py-40">
      {/* soft section lighting (static gradient, no blur filter) */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-full bg-[radial-gradient(45%_40%_at_15%_30%,rgba(59,107,255,0.12),transparent_70%)]"
      />
      <div className="relative mx-auto max-w-6xl">
        <SectionHeader id="services-title" eyebrow="Services" title="Four disciplines. One creative partner." gradientFrom={3}>
          Everything your brand needs to look sharp, move well and stay consistent across every screen.
        </SectionHeader>

        <ul className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => {
            const Icon = icons[s.icon]
            return (
              <li key={s.id}>
                <Reveal delay={i * 0.09} className="h-full">
                  <motion.article
                    data-cursor="card"
                    whileHover={{ y: -8 }}
                    whileTap={{ scale: 0.985 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 22 }}
                    style={{ '--a': s.from, '--b': s.to } as CSSProperties}
                    className="glass group relative flex h-full flex-col overflow-hidden rounded-3xl p-6 md:p-7"
                  >
                    {/* accent glow that fades in on hover/press */}
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-0 -z-10 opacity-0 transition-opacity duration-500 group-hover:opacity-30 group-active:opacity-30"
                      style={{ background: 'radial-gradient(420px circle at 50% 0%, var(--a), transparent 65%)' }}
                    />
                    <div className="flex items-start justify-between">
                      <div
                        className="grid size-12 place-items-center rounded-2xl text-white shadow-[0_10px_30px_-8px_var(--a)]"
                        style={{ background: 'linear-gradient(135deg, var(--a), var(--b))' }}
                      >
                        <Icon className="size-[1.35rem]" strokeWidth={1.7} aria-hidden="true" />
                      </div>
                      <span className="text-xs tabular-nums text-white/30" aria-hidden="true">
                        {String(i + 1).padStart(2, '0')}
                      </span>
                    </div>

                    <h3 className="mt-7 text-xl font-semibold tracking-tight">{s.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-white/60">{s.description}</p>

                    <ul className="mt-6 flex flex-wrap gap-2">
                      {s.points.map((p) => (
                        <li key={p} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs text-white/60">
                          {p}
                        </li>
                      ))}
                    </ul>
                    {/* accent underline, pinned to the card bottom */}
                    <div className="mt-auto pt-7" aria-hidden="true">
                      <div
                        className="h-px w-full origin-left scale-x-[0.18] transition-transform duration-700 group-hover:scale-x-100"
                        style={{ background: 'linear-gradient(90deg, var(--a), var(--b))' }}
                      />
                    </div>
                  </motion.article>
                </Reveal>
              </li>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
