import { motion, useMotionValue, useSpring, useTransform, type MotionValue } from 'framer-motion'
import { useEffect, useState } from 'react'
import { useFinePointer, useReducedMotion } from '../hooks/useEnv'

type Mood = 'idle' | 'link' | 'card'

// Where the eyes sit relative to the real pointer (they trail it, like a curious companion).
const OFFSET_X = 18
const OFFSET_Y = 20
// Eye geometry (px)
const EYE_W = 20
const EYE_H = 26
const GAP = 6
const MAX_LOOK = 4.5

const INTERACTIVE = 'a, button, [role="button"], input, textarea, select, summary'
const CARD = '[data-cursor="card"]'

const eyeMood = {
  idle: { scale: 1, scaleY: 1 },
  link: { scale: 1.22, scaleY: 1 }, // eyes widen when something is clickable
  card: { scale: 1, scaleY: 0.72 }, // eyes narrow, curious, over cards
} as const
const pupilMood = {
  idle: 1,
  link: 1.35,
  card: 0.8,
} as const

/**
 * Premium "eyes" cursor. The native pointer stays visible (keeps the page accessible);
 * the eyes follow it with spring physics and the pupils look at the actual pointer.
 * Rendered only for mouse/trackpad users, never on touch devices.
 */
export default function EyeCursor() {
  const fine = useFinePointer()
  const reduced = useReducedMotion()
  if (!fine) return null
  return <Eyes reduced={reduced} />
}

function Eyes({ reduced }: { reduced: boolean }) {
  const [shown, setShown] = useState(false)
  const [mood, setMood] = useState<Mood>('idle')
  const [blink, setBlink] = useState(false)

  // Raw pointer position
  const px = useMotionValue(-100)
  const py = useMotionValue(-100)
  // Springy eye-pair position
  const spring = reduced
    ? { stiffness: 900, damping: 60, mass: 0.4 }
    : { stiffness: 230, damping: 22, mass: 0.7 }
  const tx = useTransform(px, (v) => v + OFFSET_X)
  const ty = useTransform(py, (v) => v + OFFSET_Y)
  const sx = useSpring(tx, spring)
  const sy = useSpring(ty, spring)

  // Pupil offsets: each eye looks from its own centre toward the real pointer.
  const leftCx = EYE_W / 2
  const rightCx = EYE_W + GAP + EYE_W / 2
  const lx = usePupil(px, py, sx, sy, leftCx, 0)
  const ly = usePupil(px, py, sx, sy, leftCx, 1)
  const rx = usePupil(px, py, sx, sy, rightCx, 0)
  const ry = usePupil(px, py, sx, sy, rightCx, 1)

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (e.pointerType === 'touch') return
      px.set(e.clientX)
      py.set(e.clientY)
      setShown(true)
    }
    const onOver = (e: PointerEvent) => {
      const el = e.target instanceof Element ? e.target : null
      if (!el) return
      if (el.closest(INTERACTIVE)) setMood('link')
      else if (el.closest(CARD)) setMood('card')
      else setMood('idle')
    }
    const onLeave = () => setShown(false)
    const onEnter = () => setShown(true)

    window.addEventListener('pointermove', onMove, { passive: true })
    document.addEventListener('pointerover', onOver, { passive: true })
    document.documentElement.addEventListener('mouseleave', onLeave)
    document.documentElement.addEventListener('mouseenter', onEnter)
    return () => {
      window.removeEventListener('pointermove', onMove)
      document.removeEventListener('pointerover', onOver)
      document.documentElement.removeEventListener('mouseleave', onLeave)
      document.documentElement.removeEventListener('mouseenter', onEnter)
    }
  }, [px, py])

  // Occasional natural blink (skipped for reduced motion).
  useEffect(() => {
    if (reduced) return
    let timer = 0
    let off = 0
    const schedule = () => {
      timer = window.setTimeout(() => {
        setBlink(true)
        off = window.setTimeout(() => {
          setBlink(false)
          schedule()
        }, 130)
      }, 2600 + Math.random() * 3400)
    }
    schedule()
    return () => {
      window.clearTimeout(timer)
      window.clearTimeout(off)
    }
  }, [reduced])

  const m = eyeMood[mood]

  return (
    <motion.div
      aria-hidden="true"
      className="eye-cursor pointer-events-none fixed left-0 top-0 z-[9999] flex"
      style={{ x: sx, y: sy, gap: GAP }}
      initial={false}
      animate={{ opacity: shown ? 1 : 0 }}
      transition={{ duration: 0.25 }}
    >
      <Eye pupilX={lx} pupilY={ly} mood={mood} scale={m.scale} scaleY={blink ? 0.08 : m.scaleY} />
      <Eye pupilX={rx} pupilY={ry} mood={mood} scale={m.scale} scaleY={blink ? 0.08 : m.scaleY} />
    </motion.div>
  )
}

/** Pupil offset (px) for one axis of one eye, smoothed with a soft spring. */
function usePupil(
  px: MotionValue<number>,
  py: MotionValue<number>,
  sx: MotionValue<number>,
  sy: MotionValue<number>,
  cx: number,
  axis: 0 | 1,
): MotionValue<number> {
  const raw = useTransform<number, number>([px, py, sx, sy], (v) => {
    const [mx, my, ex, ey] = v as number[]
    const dx = mx - (ex + cx)
    const dy = my - (ey + EYE_H / 2)
    const dist = Math.hypot(dx, dy) || 1
    const strength = Math.min(dist / 26, 1) * MAX_LOOK
    return axis === 0 ? (dx / dist) * strength : (dy / dist) * strength
  })
  return useSpring(raw, { stiffness: 380, damping: 28, mass: 0.5 })
}

interface EyeProps {
  pupilX: MotionValue<number>
  pupilY: MotionValue<number>
  mood: Mood
  scale: number
  scaleY: number
}

function Eye({ pupilX, pupilY, mood, scale, scaleY }: EyeProps) {
  return (
    <motion.div
      className="relative grid place-items-center rounded-full"
      style={{
        width: EYE_W,
        height: EYE_H,
        background:
          'radial-gradient(circle at 35% 25%, rgba(255,255,255,0.95), rgba(220,228,255,0.78) 55%, rgba(170,185,255,0.6))',
        border: '1px solid rgba(255,255,255,0.65)',
        boxShadow:
          '0 0 14px rgba(99,102,241,0.55), 0 0 28px rgba(34,211,238,0.25), inset 0 -3px 5px rgba(80,90,200,0.35), inset 0 1px 2px rgba(255,255,255,0.9)',
      }}
      animate={{ scale, scaleY }}
      transition={{ type: 'spring', stiffness: 420, damping: 26 }}
    >
      <motion.div
        className="relative rounded-full"
        style={{
          width: 9,
          height: 9,
          x: pupilX,
          y: pupilY,
          background: 'radial-gradient(circle at 35% 30%, #67e8f9, #4f46e5 55%, #1e1b4b)',
          boxShadow: '0 0 6px rgba(79,70,229,0.8)',
        }}
        animate={{ scale: pupilMood[mood] }}
        transition={{ type: 'spring', stiffness: 400, damping: 22 }}
      >
        <span className="absolute left-[1.5px] top-[1.5px] size-[3px] rounded-full bg-white/90" />
      </motion.div>
    </motion.div>
  )
}
