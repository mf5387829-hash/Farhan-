import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef, type MutableRefObject } from 'react'
import * as THREE from 'three'

/**
 * Lightweight liquid-glass 3D hero.
 * One custom shader (fresnel + fake refraction + specular) on a gently wobbling
 * icosphere, two thin rings and three satellites. No textures, no models, no
 * environment maps, no transmission pass: just ~15k triangles on desktop.
 */

const vertexShader = /* glsl */ `
  uniform float uTime;
  varying vec3 vNormal;
  varying vec3 vView;
  varying vec3 vPos;

  void main() {
    vec3 q = normalize(position) * 2.0;
    float wob = sin(q.x * 1.7 + uTime * 0.8)
              + sin(q.y * 2.1 + uTime * 0.6)
              + sin(q.z * 1.9 + uTime * 0.7);
    vec3 p = position + normal * wob * 0.045 * length(position);

    // Cheap normal perturbation so the highlights ripple like liquid.
    vec3 n = normalize(normal + 0.18 * vec3(
      sin(q.y * 3.0 + uTime),
      sin(q.z * 3.0 + uTime * 1.1),
      sin(q.x * 3.0 + uTime * 0.9)
    ));

    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    vNormal = normalize(normalMatrix * n);
    vView = normalize(-mv.xyz);
    vPos = position;
    gl_Position = projectionMatrix * mv;
  }
`

const fragmentShader = /* glsl */ `
  precision highp float;
  uniform float uTime;
  varying vec3 vNormal;
  varying vec3 vView;
  varying vec3 vPos;

  const vec3 BLUE   = vec3(0.17, 0.38, 1.00);
  const vec3 VIOLET = vec3(0.55, 0.33, 0.98);
  const vec3 CYAN   = vec3(0.13, 0.85, 0.95);
  const vec3 PINK   = vec3(0.95, 0.30, 0.65);

  void main() {
    vec3 N = normalize(vNormal);
    vec3 V = normalize(vView);

    float fres = pow(1.0 - max(dot(N, V), 0.0), 2.4);

    // Fake refraction: bend the view ray and use it to sample the gradient.
    vec3 r = refract(-V, N, 0.78);
    float t = r.x * 1.6 + r.y * 1.3 + vPos.y * 0.25 + uTime * 0.12;
    float a = 0.5 + 0.5 * sin(t * 3.0);
    float b = 0.5 + 0.5 * sin(t * 2.0 + 2.0);
    float c = 0.5 + 0.5 * sin(t * 1.3 + 1.0);
    vec3 col = mix(mix(BLUE, VIOLET, a), mix(CYAN, PINK, b), c);

    // Two soft lights: warm key top-left, cool rim bottom-right.
    vec3 L1 = normalize(vec3(-0.55, 0.8, 0.65));
    vec3 L2 = normalize(vec3(0.7, -0.4, 0.5));
    float s1 = pow(max(dot(reflect(-L1, N), V), 0.0), 48.0);
    float s2 = pow(max(dot(reflect(-L2, N), V), 0.0), 24.0);

    vec3 body = col * (0.12 + fres * 1.35);
    vec3 rgb = body + vec3(1.0) * s1 * 0.95 + CYAN * s2 * 0.55;
    float alpha = clamp(0.16 + fres * 0.85 + s1 * 0.6 + s2 * 0.3, 0.0, 1.0);

    gl_FragColor = vec4(rgb, alpha);
  }
`

interface PointerState {
  x: number
  y: number
  pulse: number
}

interface SceneProps {
  reduced: boolean
  low: boolean
  pointer: MutableRefObject<PointerState>
}

function Scene({ reduced, low, pointer }: SceneProps) {
  const size = useThree((s) => s.size)
  const inner = useRef<THREE.Group>(null)
  const blob = useRef<THREE.Mesh>(null)
  const ringA = useRef<THREE.Mesh>(null)
  const ringB = useRef<THREE.Mesh>(null)
  const sats = useRef<THREE.Group>(null)

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 } },
        vertexShader,
        fragmentShader,
        transparent: true,
        depthWrite: false,
        toneMapped: false,
      }),
    [],
  )
  const ringMaterial = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        color: new THREE.Color('#8fb0ff'),
        transparent: true,
        opacity: 0.38,
        depthWrite: false,
        toneMapped: false,
      }),
    [],
  )
  useEffect(
    () => () => {
      material.dispose()
      ringMaterial.dispose()
    },
    [material, ringMaterial],
  )

  // Layout: object sits right of the headline on wide screens, above it on portrait phones.
  const aspect = size.width / Math.max(size.height, 1)
  const wide = aspect > 1.1
  const position: [number, number, number] = wide ? [1.7, 0.05, 0] : [0, 1.15, 0]
  const scale = wide ? 1 : 0.58

  useFrame((_, dt) => {
    const d = Math.min(dt, 0.05) // never jump after the loop was paused
    const u = material.uniforms.uTime
    if (!reduced) u.value += d
    const t = u.value as number

    const g = inner.current
    if (!g) return

    const p = pointer.current
    p.pulse = Math.max(0, p.pulse - d * 1.8)
    const ease = Math.min(1, d * 3)
    g.rotation.y += ((reduced ? 0 : p.x * 0.4) - g.rotation.y) * ease
    g.rotation.x += ((reduced ? 0 : p.y * 0.28) - g.rotation.x) * ease
    g.scale.setScalar(1 + p.pulse * 0.09)

    if (blob.current) {
      blob.current.rotation.y = t * 0.12
      blob.current.rotation.x = Math.sin(t * 0.2) * 0.2
    }
    if (ringA.current) ringA.current.rotation.z = t * 0.18
    if (ringB.current) ringB.current.rotation.z = -t * 0.12
    if (sats.current) {
      sats.current.rotation.y = t * 0.22
      sats.current.rotation.z = Math.sin(t * 0.3) * 0.25
    }
  })

  return (
    <group position={position} scale={scale}>
      <group ref={inner}>
        <mesh ref={blob} material={material}>
          <icosahedronGeometry args={[1.3, low ? 10 : 24]} />
        </mesh>
        <mesh ref={ringA} rotation={[Math.PI / 2.5, 0.3, 0]} material={ringMaterial}>
          <torusGeometry args={[1.95, 0.011, 6, low ? 72 : 140]} />
        </mesh>
        <mesh ref={ringB} rotation={[Math.PI / 1.9, -0.5, 0.4]} material={ringMaterial}>
          <torusGeometry args={[2.3, 0.008, 6, low ? 72 : 140]} />
        </mesh>
        <group ref={sats}>
          <mesh position={[2.15, 0.35, 0.2]} material={material}>
            <icosahedronGeometry args={[0.17, 4]} />
          </mesh>
          <mesh position={[-1.9, -0.95, 0.6]} material={material}>
            <icosahedronGeometry args={[0.1, 4]} />
          </mesh>
          <mesh position={[0.3, 1.95, -0.8]} material={material}>
            <icosahedronGeometry args={[0.2, 4]} />
          </mesh>
        </group>
      </group>
    </group>
  )
}

interface HeroSceneProps {
  /** Hero is on screen: run the render loop. Otherwise render on demand only. */
  active: boolean
  reduced: boolean
  low: boolean
  onReady: () => void
  onLost: () => void
}

export default function HeroScene({ active, reduced, low, onReady, onLost }: HeroSceneProps) {
  const pointer = useRef<PointerState>({ x: 0, y: 0, pulse: 0 })

  // One passive listener that only writes to a ref: no React re-renders.
  useEffect(() => {
    if (reduced) return
    const move = (e: PointerEvent) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1
      pointer.current.y = (e.clientY / window.innerHeight) * 2 - 1
    }
    // Touch: a tap makes the object pulse (replaces hover on phones).
    const down = () => {
      pointer.current.pulse = 1
    }
    window.addEventListener('pointermove', move, { passive: true })
    window.addEventListener('pointerdown', down, { passive: true })
    return () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerdown', down)
    }
  }, [reduced])

  return (
    <Canvas
      frameloop={active && !reduced ? 'always' : 'demand'}
      dpr={[1, low ? 1.25 : 1.75]}
      camera={{ position: [0, 0, 6], fov: 40 }}
      gl={{ antialias: !low, alpha: true, powerPreference: 'low-power', stencil: false }}
      style={{ pointerEvents: 'none' }}
      onCreated={({ gl }) => {
        gl.domElement.addEventListener('webglcontextlost', (e) => {
          e.preventDefault()
          onLost()
        })
        onReady()
      }}
    >
      <Scene reduced={reduced} low={low} pointer={pointer} />
    </Canvas>
  )
}
