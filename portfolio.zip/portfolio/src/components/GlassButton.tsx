import { motion } from 'framer-motion'
import type { MouseEvent, ReactNode } from 'react'
import { useReducedMotion } from '../hooks/useEnv'
import { scrollToId } from '../lib/scroll'

interface GlassButtonProps {
  children: ReactNode
  /** In-page anchors ("#projects") scroll smoothly; other URLs open normally. */
  href?: string
  variant?: 'primary' | 'ghost'
  icon?: ReactNode
  onClick?: () => void
  disabled?: boolean
  className?: string
}

export default function GlassButton({
  children,
  href,
  variant = 'ghost',
  icon,
  onClick,
  disabled = false,
  className = '',
}: GlassButtonProps) {
  const reduced = useReducedMotion()
  const classes = `glass glass-btn ${variant === 'primary' ? 'glass-btn-primary' : ''} ${className}`
  const motionProps = disabled
    ? {}
    : { whileHover: { y: -2 }, whileTap: { scale: 0.97 }, transition: { type: 'spring' as const, stiffness: 400, damping: 26 } }

  const content = (
    <>
      <span className="relative z-10">{children}</span>
      {icon ? <span className="relative z-10 shrink-0">{icon}</span> : null}
    </>
  )

  if (href) {
    const handleClick = (e: MouseEvent<HTMLAnchorElement>) => {
      if (href.startsWith('#')) {
        e.preventDefault()
        scrollToId(href.slice(1), reduced)
      }
      onClick?.()
    }
    const external = /^https?:\/\//.test(href)
    return (
      <motion.a
        href={href}
        className={classes}
        onClick={handleClick}
        {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
        {...motionProps}
      >
        {content}
      </motion.a>
    )
  }

  return (
    <motion.button
      type="button"
      className={classes}
      onClick={disabled ? undefined : onClick}
      aria-disabled={disabled || undefined}
      {...motionProps}
    >
      {content}
    </motion.button>
  )
}
