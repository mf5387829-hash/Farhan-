import { Info } from 'lucide-react'
import { projects } from '../data/content'
import ProjectCard from './ProjectCard'
import { Reveal } from './Reveal'
import SectionHeader from './SectionHeader'

export default function Projects() {
  return (
    <section id="projects" aria-labelledby="projects-title" className="relative px-6 py-28 md:py-40">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(50%_35%_at_85%_20%,rgba(236,72,153,0.1),transparent_70%),radial-gradient(45%_35%_at_10%_80%,rgba(34,211,238,0.09),transparent_70%)]"
      />
      <div className="relative mx-auto max-w-6xl">
        <SectionHeader id="projects-title" eyebrow="Selected work" title="A look at what I make." gradientFrom={4}>
          One showcase for video, web, branding and social campaigns.
        </SectionHeader>

        <Reveal delay={0.2} className="mt-6">
          <p className="glass-lite inline-flex items-start gap-2.5 rounded-2xl px-4 py-3 text-xs leading-relaxed text-white/60 sm:items-center">
            <Info className="mt-0.5 size-4 shrink-0 text-aqua sm:mt-0" aria-hidden="true" />
            These are demonstration projects with placeholder content. Swap in your real work in
            <code className="rounded bg-white/10 px-1.5 py-0.5 text-white/80">src/data/content.ts</code>
          </p>
        </Reveal>

        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p, i) => (
            <li key={p.id}>
              <ProjectCard project={p} index={i} />
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
