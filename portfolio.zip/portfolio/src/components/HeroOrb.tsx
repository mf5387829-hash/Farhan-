/**
 * Pure-CSS liquid-glass orb. It's both the placeholder shown while the 3D scene
 * downloads (so nothing jumps) and the permanent fallback when WebGL is
 * unavailable, the user prefers saved data, or the GPU context is lost.
 * Only `transform` animates, so it stays on the compositor.
 */
export default function HeroOrb({ className = '' }: { className?: string }) {
  return (
    <div aria-hidden="true" className={`relative aspect-square ${className}`}>
      <div className="orb absolute inset-0 animate-spin-slower" />
      <div className="orb-core" />
      <div className="orb-gloss" />
      {/* thin glass rings for depth */}
      <div className="absolute -inset-[14%] rounded-full border border-white/15 [transform:rotateX(68deg)_rotateZ(20deg)]" />
      <div className="absolute -inset-[26%] rounded-full border border-white/10 [transform:rotateX(72deg)_rotateZ(-30deg)]" />
    </div>
  )
}
