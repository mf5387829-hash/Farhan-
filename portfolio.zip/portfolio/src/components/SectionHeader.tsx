import type { ReactNode } from 'react'
import { Reveal, RevealText } from './Reveal'

interface SectionHeaderProps {
  eyebrow: string
  title: string
  /** Index of the first word that gets the gradient (omit for none). */
  gradientFrom?: number
  children?: ReactNode
  id?: string
}

export default function SectionHeader({ eyebrow, title, gradientFrom, children, id }: SectionHeaderProps) {
  return (
    <header className="max-w-3xl">
      <Reveal y={14}>
        <p className="eyebrow flex items-center gap-3">
          <span className="h-px w-8 bg-gradient-to-r from-aqua to-violet" aria-hidden="true" />
          {eyebrow}
        </p>
      </Reveal>
      <h2 id={id} className="mt-5 text-[clamp(1.9rem,5.4vw,3.6rem)] font-bold leading-[1.08] tracking-tight">
        <RevealText
          text={title}
          wordClassName={(i) => (gradientFrom !== undefined && i >= gradientFrom ? 'text-gradient' : undefined)}
        />
      </h2>
      {children ? (
        <Reveal delay={0.15} className="mt-5 text-base leading-relaxed text-white/60 md:text-lg">
          {children}
        </Reveal>
      ) : null}
    </header>
  )
}
