import { motion } from 'framer-motion'
import { ArrowUpRight, Github, Instagram, Linkedin, Mail, Send, Youtube, type LucideIcon } from 'lucide-react'
import { useState } from 'react'
import { services, site } from '../data/content'
import GlassButton from './GlassButton'
import { Reveal, RevealText } from './Reveal'

const socialIcons: Record<(typeof site.socials)[number]['id'], LucideIcon> = {
  instagram: Instagram,
  youtube: Youtube,
  linkedin: Linkedin,
  github: Github,
}

export default function Contact() {
  const [selected, setSelected] = useState<string[]>([])
  const hasEmail = site.email.trim().length > 0

  const toggle = (title: string) =>
    setSelected((cur) => (cur.includes(title) ? cur.filter((t) => t !== title) : [...cur, title]))

  const inquiryHref = (() => {
    if (!hasEmail) return undefined
    const list = selected.length ? selected.join(', ') : 'a project'
    const subject = encodeURIComponent(`Project inquiry: ${selected.length ? selected.join(', ') : 'new project'}`)
    const body = encodeURIComponent(
      `Hi ${site.name},\n\nI'd like to talk about ${list}.\n\nA bit about the project:\n\n`,
    )
    return `mailto:${site.email.trim()}?subject=${subject}&body=${body}`
  })()

  return (
    <section id="contact" aria-labelledby="contact-title" className="relative px-6 py-28 md:py-40">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(55%_45%_at_50%_30%,rgba(99,102,241,0.18),transparent_70%),radial-gradient(40%_30%_at_80%_90%,rgba(236,72,153,0.1),transparent_70%)]"
      />
      <div className="relative mx-auto max-w-4xl text-center">
        <Reveal y={14}>
          <p className="eyebrow">Contact</p>
        </Reveal>
        <h2
          id="contact-title"
          className="mt-5 text-[clamp(2.1rem,7.2vw,4.6rem)] font-extrabold leading-[1.04] tracking-tight"
        >
          <RevealText
            text="Let's Build Something Great"
            wordClassName={(i, total) => (i >= total - 2 ? 'text-gradient' : undefined)}
          />
        </h2>
        <Reveal delay={0.15} className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-white/60 md:text-lg">
          <p>Have an idea, a launch or a brand that needs a lift? Tell me about it and let&rsquo;s make it real.</p>
        </Reveal>

        <Reveal delay={0.25} className="mt-9">
          <div className="flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
            <GlassButton
              variant="primary"
              href={hasEmail ? `mailto:${site.email.trim()}` : undefined}
              disabled={!hasEmail}
              icon={<Mail className="size-4" aria-hidden="true" />}
            >
              Email Me
            </GlassButton>
          </div>
          {!hasEmail ? (
            <p className="mt-4 text-xs text-white/40">
              Placeholder: add your email in <code className="rounded bg-white/10 px-1.5 py-0.5">src/data/content.ts</code> to
              activate the email buttons.
            </p>
          ) : null}
        </Reveal>

        <Reveal delay={0.3} className="mt-10">
          <ul className="flex flex-wrap justify-center gap-3" aria-label="Social links">
            {site.socials.map((s) => {
              const Icon = socialIcons[s.id]
              const active = s.href.trim().length > 0
              const cls =
                'glass grid size-12 place-items-center rounded-full text-white/75 transition-colors focus-visible:text-white'
              return (
                <li key={s.id}>
                  {active ? (
                    <motion.a
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={s.label}
                      whileHover={{ y: -3 }}
                      whileTap={{ scale: 0.94 }}
                      className={`${cls} hover:text-white`}
                    >
                      <Icon className="size-[1.15rem]" strokeWidth={1.7} aria-hidden="true" />
                    </motion.a>
                  ) : (
                    <span
                      role="img"
                      aria-label={`${s.label} (link not added yet)`}
                      title={`${s.label}: add your link in src/data/content.ts`}
                      className={`${cls} cursor-not-allowed opacity-45`}
                    >
                      <Icon className="size-[1.15rem]" strokeWidth={1.7} aria-hidden="true" />
                    </span>
                  )}
                </li>
              )
            })}
          </ul>
        </Reveal>

        {/* Project inquiry call-to-action */}
        <Reveal delay={0.35} className="mt-16">
          <div data-cursor="card" className="glass mx-auto max-w-2xl rounded-[2rem] p-6 text-left md:p-9">
            <h3 className="text-xl font-semibold tracking-tight md:text-2xl">Start a project inquiry</h3>
            <p className="mt-2 text-sm text-white/55">Pick what you need, then send a ready-to-go email.</p>

            <div className="mt-6 flex flex-wrap gap-2.5" role="group" aria-label="Services you need">
              {services.map((s) => {
                const on = selected.includes(s.title)
                return (
                  <button
                    key={s.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggle(s.title)}
                    className={`min-h-11 rounded-full border px-4 text-sm transition-colors ${
                      on
                        ? 'border-white/40 bg-gradient-to-r from-electric/40 to-violet/40 text-white'
                        : 'border-white/12 bg-white/[0.03] text-white/65 hover:border-white/25 hover:text-white'
                    }`}
                  >
                    {s.title}
                  </button>
                )
              })}
            </div>

            <div className="mt-7">
              <GlassButton
                variant="primary"
                href={inquiryHref}
                disabled={!hasEmail}
                icon={hasEmail ? <ArrowUpRight className="size-4" aria-hidden="true" /> : <Send className="size-4" aria-hidden="true" />}
                className="w-full sm:w-auto"
              >
                Send Inquiry
              </GlassButton>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
