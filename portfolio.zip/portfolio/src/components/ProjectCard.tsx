import {
  motion,
  useMotionTemplate,
  useMotionValue,
  useSpring,
} from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import type { PointerEvent } from 'react'
import type { Project } from '../data/content'
import { useReducedMotion } from '../hooks/useEnv'
import { Reveal } from './Reveal'
import ProjectVisual from './ProjectVisual'

const MAX_TILT = 8 // degrees

/**
 * Project card with a subtle 3D tilt + moving glare. Works with mouse hover and with
 * a finger resting on the card; resets cleanly on leave / cancel (e.g. when scrolling starts).
 */
export default function ProjectCard({ project, index }: { project: Project; index: number }) {
  const reduced = useReducedMotion()
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const tiltX = useSpring(rx, { stiffness: 220, damping: 20 })
  const tiltY = useSpring(ry, { stiffness: 220, damping: 20 })
  const gx = useMotionValue(50)
  const gy = useMotionValue(0)
  const glare = useMotionTemplate`radial-gradient(340px circle at ${gx}% ${gy}%, rgba(255,255,255,0.16), transparent 60%)`

  const onMove = (e: PointerEvent<HTMLElement>) => {
    if (reduced) return
    const r = e.currentTarget.getBoundingClientRect()
    const x = (e.clientX - r.left) / r.width
    const y = (e.clientY - r.top) / r.height
    ry.set((x - 0.5) * 2 * MAX_TILT)
    rx.set(-(y - 0.5) * 2 * MAX_TILT)
    gx.set(x * 100)
    gy.set(y * 100)
  }
  const reset = () => {
    rx.set(0)
    ry.set(0)
  }

  // Stagger by column so a row cascades left to right.
  const delay = (index % 3) * 0.1

  return (
    <Reveal delay={delay} className="h-full [perspective:1200px]">
      <motion.article
        data-cursor="card"
        onPointerMove={onMove}
        onPointerLeave={reset}
        onPointerCancel={reset}
        onPointerUp={(e) => {
          if (e.pointerType === 'touch') reset()
        }}
        whileTap={{ scale: 0.985 }}
        style={{ rotateX: tiltX, rotateY: tiltY, transformPerspective: 1000, transformStyle: 'preserve-3d' }}
        className="glass-lite group relative flex h-full flex-col rounded-3xl p-2.5"
      >
        <div className="relative min-h-[15rem] flex-1 overflow-hidden rounded-[1.25rem]">
          <ProjectVisual project={project} />
          <span className="absolute left-3 top-3 z-10 rounded-full border border-white/25 bg-black/50 px-2.5 py-1 text-[0.62rem] font-medium uppercase tracking-[0.18em] text-white/85">
            Demo project
          </span>
          {project.href ? (
            <span className="absolute right-3 top-3 z-10 grid size-8 place-items-center rounded-full border border-white/25 bg-black/50 text-white opacity-0 transition-opacity group-hover:opacity-100 group-focus-within:opacity-100">
              <ArrowUpRight className="size-4" aria-hidden="true" />
            </span>
          ) : null}
          <motion.div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-active:opacity-100" style={{ background: glare }} />
        </div>

        <div className="p-4 pb-3 [transform:translateZ(26px)]">
          <p className="eyebrow flex items-center gap-2 !text-[0.66rem]">
            <span
              className="size-1.5 rounded-full"
              style={{ background: `linear-gradient(135deg, ${project.from}, ${project.to})` }}
              aria-hidden="true"
            />
            {project.category}
          </p>
          <h3 className="mt-2 text-lg font-semibold tracking-tight">
            {project.href ? (
              <a
                href={project.href}
                target="_blank"
                rel="noopener noreferrer"
                className="after:absolute after:inset-0 after:content-['']"
              >
                {project.title}
              </a>
            ) : (
              project.title
            )}
          </h3>
          <p className="mt-1.5 text-sm leading-relaxed text-white/55">{project.blurb}</p>
          <ul className="mt-4 flex flex-wrap gap-2">
            {project.tags.map((t) => (
              <li key={t} className="rounded-full border border-white/10 px-2.5 py-1 text-[0.7rem] text-white/50">
                {t}
              </li>
            ))}
          </ul>
        </div>
      </motion.article>
    </Reveal>
  )
}
