import { motion } from 'framer-motion'
import { Home, Layers, LayoutGrid, Mail, User, type LucideIcon } from 'lucide-react'
import type { MouseEvent } from 'react'
import { useActiveSection } from '../hooks/useActiveSection'
import { useReducedMotion } from '../hooks/useEnv'
import { EASE } from '../lib/motion'
import { scrollToId } from '../lib/scroll'

const items: { id: string; label: string; Icon: LucideIcon }[] = [
  { id: 'home', label: 'Home', Icon: Home },
  { id: 'services', label: 'Services', Icon: Layers },
  { id: 'projects', label: 'Projects', Icon: LayoutGrid },
  { id: 'about', label: 'About', Icon: User },
  { id: 'contact', label: 'Contact', Icon: Mail },
]
const ids = items.map((i) => i.id)

const pillSpring = { type: 'spring' as const, stiffness: 380, damping: 32 }
const pillClass =
  'absolute inset-0 -z-10 rounded-full bg-gradient-to-b from-white/20 to-white/5 ring-1 ring-white/15 shadow-[inset_0_1px_0_rgba(255,255,255,0.35)]'

export default function Nav() {
  const active = useActiveSection(ids)
  const reduced = useReducedMotion()

  const go = (id: string) => (e: MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault()
    scrollToId(id, reduced)
  }

  return (
    <>
      {/* Desktop / tablet: floating glass pill at the top */}
      <div className="pointer-events-none fixed inset-x-0 top-4 z-50 hidden justify-center md:flex">
        <motion.nav
          aria-label="Primary"
          initial={{ y: -24, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.9, delay: 0.25, ease: EASE }}
          className="glass pointer-events-auto rounded-full p-1.5"
        >
          <ul className="flex items-center gap-1">
            {items.map(({ id, label }) => (
              <li key={id}>
                <a
                  href={`#${id}`}
                  onClick={go(id)}
                  aria-current={active === id ? 'location' : undefined}
                  className="relative block rounded-full px-5 py-2.5 text-sm text-white/65 transition-colors hover:text-white aria-[current=location]:text-white"
                >
                  {active === id ? <motion.span layoutId="nav-pill-desktop" className={pillClass} transition={pillSpring} /> : null}
                  <span className="relative">{label}</span>
                </a>
              </li>
            ))}
          </ul>
        </motion.nav>
      </div>

      {/* Mobile: compact thumb-friendly dock at the bottom */}
      <div className="pointer-events-none fixed inset-x-0 bottom-[max(0.75rem,env(safe-area-inset-bottom))] z-50 flex justify-center px-3 md:hidden">
        <motion.nav
          aria-label="Primary"
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.9, delay: 0.4, ease: EASE }}
          className="glass pointer-events-auto rounded-full p-1.5"
        >
          <ul className="flex items-center">
            {items.map(({ id, label, Icon }) => (
              <li key={id}>
                <a
                  href={`#${id}`}
                  onClick={go(id)}
                  aria-current={active === id ? 'location' : undefined}
                  className="relative flex h-[3.4rem] w-[3.6rem] flex-col items-center justify-center gap-0.5 rounded-full text-white/60 transition-colors active:scale-95 aria-[current=location]:text-white min-[380px]:w-[3.9rem]"
                >
                  {active === id ? <motion.span layoutId="nav-pill-mobile" className={pillClass} transition={pillSpring} /> : null}
                  <Icon className="relative size-[1.15rem]" strokeWidth={1.8} aria-hidden="true" />
                  <span className="relative text-[0.62rem] leading-none tracking-wide">{label}</span>
                </a>
              </li>
            ))}
          </ul>
        </motion.nav>
      </div>
    </>
  )
}
