import { motion, useScroll, useTransform } from 'framer-motion'
import { ArrowDown, ArrowUpRight, Sparkles } from 'lucide-react'
import { Component, lazy, Suspense, useEffect, useRef, useState, type ReactNode } from 'react'
import { useReducedMotion } from '../hooks/useEnv'
import { canUseWebGL, isLowPower, prefersSaveData, whenIdle } from '../lib/device'
import { EASE } from '../lib/motion'
import GlassButton from './GlassButton'
import HeroOrb from './HeroOrb'
import { RevealText } from './Reveal'

// The 3D scene (three.js + react-three-fiber) is its own chunk and only loads
// after first paint, when the browser is idle.
const HeroScene = lazy(() => import('./HeroScene'))

/** If the 3D scene throws (rare GPU/driver problems), quietly keep the CSS orb. */
class SceneBoundary extends Component<{ children: ReactNode; onError: () => void }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  componentDidCatch() {
    this.props.onError()
  }
  render() {
    return this.state.failed ? null : this.props.children
  }
}

const lines = ['I DESIGN.', 'I CREATE.', 'I ELEVATE.']

export default function Hero() {
  const reduced = useReducedMotion()
  const sectionRef = useRef<HTMLElement>(null)
  const [mount3D, setMount3D] = useState(false)
  const [ready, setReady] = useState(false)
  const [onScreen, setOnScreen] = useState(true)
  const [low] = useState(() => isLowPower())

  // Lazy-load the 3D scene only when WebGL works and the user isn't saving data.
  useEffect(() => {
    if (!canUseWebGL() || prefersSaveData()) return
    return whenIdle(() => setMount3D(true))
  }, [])

  // Pause the render loop whenever the hero is scrolled out of view.
  useEffect(() => {
    const el = sectionRef.current
    if (!el) return
    const io = new IntersectionObserver(([entry]) => setOnScreen(entry.isIntersecting), { threshold: 0 })
    io.observe(el)
    return () => io.disconnect()
  }, [])

  // Subtle scroll parallax (transform/opacity only).
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end start'] })
  const sceneY = useTransform(scrollYProgress, [0, 1], ['0%', '16%'])
  const textY = useTransform(scrollYProgress, [0, 1], ['0%', '-8%'])
  const textOpacity = useTransform(scrollYProgress, [0, 0.65], [1, 0])

  return (
    <section
      id="home"
      ref={sectionRef}
      className="relative flex min-h-svh items-end overflow-hidden px-6 pb-32 pt-28 md:items-center md:pb-24"
    >
      {/* Background: CSS orb (placeholder/fallback) + lazy 3D canvas */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={reduced ? undefined : { y: sceneY }}
      >
        <div
          className={`absolute left-1/2 top-[22%] w-[min(66vw,300px)] -translate-x-1/2 -translate-y-1/2 transition-opacity duration-1000 md:left-[71%] md:top-1/2 md:w-[min(34vw,460px)] ${
            ready ? 'opacity-0' : 'opacity-100'
          }`}
        >
          <HeroOrb />
        </div>
        {mount3D ? (
          <div className={`absolute inset-0 transition-opacity duration-1000 ${ready ? 'opacity-100' : 'opacity-0'}`}>
            <SceneBoundary onError={() => setReady(false)}>
              <Suspense fallback={null}>
                <HeroScene
                  active={onScreen}
                  reduced={reduced}
                  low={low}
                  onReady={() => setReady(true)}
                  onLost={() => setReady(false)}
                />
              </Suspense>
            </SceneBoundary>
          </div>
        ) : null}
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-b from-transparent to-[#05060a]" />
      </motion.div>

      <motion.div
        className="relative z-10 mx-auto w-full max-w-6xl"
        style={reduced ? undefined : { y: textY, opacity: textOpacity }}
      >
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: EASE }}
          className="glass-lite inline-flex items-center gap-2 rounded-full px-4 py-2"
        >
          <Sparkles className="size-3.5 text-aqua" aria-hidden="true" />
          <span className="eyebrow !text-[0.68rem]">Freelance creative studio</span>
        </motion.div>

        <h1
          aria-label={lines.join(' ')}
          className="mt-6 text-[clamp(2.25rem,8.6vw,6.5rem)] font-extrabold uppercase leading-[0.98] tracking-tight"
        >
          {lines.map((line, i) => (
            <RevealText
              key={line}
              text={line}
              onMount
              delay={0.25 + i * 0.22}
              className="block"
              wordClassName={() => (i === lines.length - 1 ? 'text-gradient' : undefined)}
            />
          ))}
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.0, ease: EASE }}
          className="mt-6 max-w-xl text-base leading-relaxed text-white/65 md:text-lg"
        >
          Creative digital experiences, designed to make your brand unforgettable.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.2, ease: EASE }}
          className="mt-9 flex flex-col gap-3 sm:flex-row"
        >
          <GlassButton href="#projects" variant="primary" icon={<ArrowUpRight className="size-4" aria-hidden="true" />}>
            Explore My Work
          </GlassButton>
          <GlassButton href="#contact">Let&rsquo;s Collaborate</GlassButton>
        </motion.div>
      </motion.div>

      <motion.div
        aria-hidden="true"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 1 }}
        className="absolute inset-x-0 bottom-8 hidden justify-center md:flex"
      >
        <div className="glass-lite grid size-11 animate-cue-bob place-items-center rounded-full">
          <ArrowDown className="size-4 text-white/70" />
        </div>
      </motion.div>
    </section>
  )
}
