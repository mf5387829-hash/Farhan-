import { motion, useScroll, useTransform, type MotionValue } from 'framer-motion'
import { Clapperboard, Code2, Shapes, Sparkles, type LucideIcon } from 'lucide-react'
import { useRef, type ReactNode } from 'react'
import { site } from '../data/content'
import { useReducedMotion } from '../hooks/useEnv'
import { Reveal } from './Reveal'
import SectionHeader from './SectionHeader'

const steps = [
  { n: '01', label: 'Discover' },
  { n: '02', label: 'Design' },
  { n: '03', label: 'Deliver' },
]

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  return (parts[0]?.[0] ?? '') + (parts.length > 1 ? parts[parts.length - 1][0] : '')
}

function FloatChip({
  y,
  className,
  float,
  Icon,
  children,
}: {
  y: MotionValue<number> | undefined
  className: string
  float: string
  Icon: LucideIcon
  children: ReactNode
}) {
  return (
    <motion.div style={y ? { y } : undefined} className={`absolute ${className}`} aria-hidden="true">
      <div className={`glass flex items-center gap-2 rounded-full py-2 pl-2.5 pr-4 text-xs text-white/80 ${float}`}>
        <span className="grid size-7 place-items-center rounded-full bg-white/10">
          <Icon className="size-3.5" strokeWidth={1.8} />
        </span>
        {children}
      </div>
    </motion.div>
  )
}

export default function About() {
  const reduced = useReducedMotion()
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  // Each floating chip drifts at a different speed: gentle depth, transform only.
  const slow = useTransform(scrollYProgress, [0, 1], [30, -30])
  const mid = useTransform(scrollYProgress, [0, 1], [60, -60])
  const fast = useTransform(scrollYProgress, [0, 1], [90, -90])
  const glowY = useTransform(scrollYProgress, [0, 1], [-40, 40])

  return (
    <section id="about" aria-labelledby="about-title" className="relative px-6 py-28 md:py-40">
      <div className="relative mx-auto grid max-w-6xl items-center gap-16 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <SectionHeader id="about-title" eyebrow="About" title="A multidisciplinary digital creator." gradientFrom={1} />
          <div className="mt-7 space-y-5 text-base leading-relaxed text-white/60 md:text-lg">
            {site.about.map((p, i) => (
              <Reveal key={i} delay={0.1 + i * 0.1} y={18}>
                <p>{p}</p>
              </Reveal>
            ))}
          </div>
          <Reveal delay={0.3} className="mt-9">
            <ol className="flex flex-wrap gap-3">
              {steps.map((s) => (
                <li key={s.n} className="glass-lite flex items-center gap-3 rounded-full py-2.5 pl-4 pr-5 text-sm text-white/80">
                  <span className="text-xs tabular-nums text-aqua">{s.n}</span>
                  {s.label}
                </li>
              ))}
            </ol>
          </Reveal>
        </div>

        <div ref={ref} className="relative mx-auto aspect-square w-full max-w-md">
          {/* background lighting (static gradient, parallax via transform) */}
          <motion.div
            aria-hidden="true"
            style={reduced ? undefined : { y: glowY }}
            className="absolute -inset-[18%] bg-[radial-gradient(closest-side,rgba(139,92,246,0.4),rgba(59,107,255,0.18)_55%,transparent_75%)]"
          />

          <Reveal className="absolute inset-0 grid place-items-center" y={36}>
            <div className="glass w-[78%] rounded-[2rem] p-6">
              <div className="flex items-center gap-4">
                <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-electric via-violet to-blush text-xl font-bold uppercase text-white shadow-[0_10px_30px_-8px_rgba(139,92,246,0.8)]">
                  {initials(site.name) || <Sparkles className="size-6" aria-hidden="true" />}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-lg font-semibold">{site.name}</p>
                  <p className="text-sm text-white/55">{site.role}</p>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-2 gap-2 text-xs text-white/70">
                {['Edit', 'Build', 'Brand', 'Grow'].map((t) => (
                  <span key={t} className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-center">
                    {t}
                  </span>
                ))}
              </div>
              {site.availability ? (
                <p className="mt-5 flex items-center gap-2 text-xs text-white/60">
                  <span className="relative grid size-2 place-items-center" aria-hidden="true">
                    <span className="absolute size-2 animate-pulse-dot rounded-full bg-emerald-400" />
                  </span>
                  {site.availability}
                </p>
              ) : null}
            </div>
          </Reveal>

          <FloatChip y={reduced ? undefined : slow} className="-left-2 top-[8%] sm:-left-6" float="animate-float" Icon={Clapperboard}>
            Motion
          </FloatChip>
          <FloatChip y={reduced ? undefined : mid} className="-right-1 top-[34%] sm:-right-8" float="animate-float-alt" Icon={Code2}>
            Code
          </FloatChip>
          <FloatChip y={reduced ? undefined : fast} className="bottom-[6%] left-[6%] sm:left-[2%]" float="animate-float" Icon={Shapes}>
            Identity
          </FloatChip>
        </div>
      </div>
    </section>
  )
}
