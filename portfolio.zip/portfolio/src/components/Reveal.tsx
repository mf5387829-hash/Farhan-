import { motion, type Variants } from 'framer-motion'
import type { ReactNode } from 'react'
import { EASE } from '../lib/motion'

interface RevealProps {
  children: ReactNode
  delay?: number
  y?: number
  className?: string
}

/** Fade-and-rise when the element scrolls into view (plays once). */
export function Reveal({ children, delay = 0, y = 28, className }: RevealProps) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '0px 0px -12% 0px' }}
      transition={{ duration: 0.85, delay, ease: EASE }}
    >
      {children}
    </motion.div>
  )
}

interface RevealTextProps {
  text: string
  className?: string
  /** Extra classes for individual words, e.g. to apply a gradient to the last ones. */
  wordClassName?: (index: number, total: number) => string | undefined
  delay?: number
  stagger?: number
  /** Play on page load (hero) instead of when scrolled into view. */
  onMount?: boolean
}

const wordVariants: Variants = {
  hidden: { y: '110%', opacity: 0 },
  show: { y: '0%', opacity: 1, transition: { duration: 0.9, ease: EASE } },
}

/**
 * Word-by-word masked text reveal. Words stay in normal text flow with real
 * spaces between them, so screen readers still read the sentence naturally.
 */
export function RevealText({
  text,
  className,
  wordClassName,
  delay = 0,
  stagger = 0.07,
  onMount = false,
}: RevealTextProps) {
  const words = text.split(' ')
  const container: Variants = {
    hidden: {},
    show: { transition: { staggerChildren: stagger, delayChildren: delay } },
  }
  const trigger = onMount
    ? { animate: 'show' as const }
    : { whileInView: 'show' as const, viewport: { once: true, margin: '0px 0px -10% 0px' } }

  return (
    <motion.span className={className} variants={container} initial="hidden" {...trigger}>
      {words.map((word, i) => (
        <span key={`${word}-${i}`}>
          <span className="inline-block overflow-hidden pb-[0.16em] -mb-[0.16em] align-bottom">
            <motion.span
              className={`inline-block ${wordClassName?.(i, words.length) ?? ''}`}
              variants={wordVariants}
            >
              {word}
            </motion.span>
          </span>
          {i < words.length - 1 ? ' ' : null}
        </span>
      ))}
    </motion.span>
  )
}
