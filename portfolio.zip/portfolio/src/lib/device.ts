/** True when the browser can create a WebGL context. */
export function canUseWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl2') ?? canvas.getContext('webgl')
    if (!gl) return false
    // Release the probe context immediately so it doesn't count against the browser's limit.
    gl.getExtension('WEBGL_lose_context')?.loseContext()
    return true
  } catch {
    return false
  }
}

/** Heuristic for phones / low-powered hardware: we draw a lighter 3D scene there. */
export function isLowPower(): boolean {
  const nav = navigator as Navigator & { deviceMemory?: number }
  const cores = nav.hardwareConcurrency ?? 8
  const memory = nav.deviceMemory ?? 8
  const smallScreen = window.matchMedia('(max-width: 767px)').matches
  return cores <= 4 || memory <= 4 || smallScreen
}

/** Respect the browser's "Data Saver" hint: skip the 3D download entirely. */
export function prefersSaveData(): boolean {
  const nav = navigator as Navigator & { connection?: { saveData?: boolean } }
  return nav.connection?.saveData === true
}

/** Run a callback when the browser is idle (with a timer fallback for Safari). */
export function whenIdle(cb: () => void, timeout = 1500): () => void {
  if (typeof window.requestIdleCallback === 'function') {
    const id = window.requestIdleCallback(cb, { timeout })
    return () => window.cancelIdleCallback(id)
  }
  const id = window.setTimeout(cb, 500)
  return () => window.clearTimeout(id)
}
