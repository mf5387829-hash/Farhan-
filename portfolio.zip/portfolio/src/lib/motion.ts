// Shared easing curve so every animation on the page feels related.
export const EASE: [number, number, number, number] = [0.22, 1, 0.36, 1]
