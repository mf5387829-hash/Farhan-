/** Smoothly scroll to a section on the same page and move keyboard focus there. */
export function scrollToId(id: string, reduced = false): void {
  const el = document.getElementById(id)
  if (!el) return
  el.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' })
  try {
    history.replaceState(null, '', `#${id}`)
  } catch {
    /* some sandboxed contexts block history changes; scrolling still works */
  }
  if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1')
  el.focus({ preventScroll: true })
}
