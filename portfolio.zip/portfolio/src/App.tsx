import { MotionConfig } from 'framer-motion'
import About from './components/About'
import Contact from './components/Contact'
import EyeCursor from './components/EyeCursor'
import Hero from './components/Hero'
import Nav from './components/Nav'
import Projects from './components/Projects'
import Services from './components/Services'
import { site } from './data/content'

export default function App() {
  return (
    // reducedMotion="user": framer-motion drops transform/layout animation for
    // visitors who enable "reduce motion", keeping only gentle fades.
    <MotionConfig reducedMotion="user">
      <div className="ambient" aria-hidden="true" />
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <EyeCursor />
      <Nav />
      <main id="main">
        <Hero />
        <Services />
        <Projects />
        <About />
        <Contact />
      </main>
      <footer className="px-6 pb-28 pt-4 text-center text-xs text-white/35 md:pb-12">
        &copy; {new Date().getFullYear()} {site.name}. Designed &amp; built with React, Three.js and Framer Motion.
      </footer>
    </MotionConfig>
  )
}
