/**
 * ============================================================
 *  EDIT THIS FILE TO MAKE THE PORTFOLIO YOURS
 *  Everything you see on the page comes from here.
 * ============================================================
 */

export const site = {
  /** Your name or studio name. */
  name: 'Your Name',
  /** One-line description shown in the About card. */
  role: 'Multidisciplinary digital creator',
  /** Shown next to the pulsing dot in the About card. Set to '' to hide it. */
  availability: 'Open to new projects',
  /**
   * Your contact email, e.g. 'hello@yourdomain.com'.
   * Left empty on purpose: the email buttons stay inactive until you add one.
   */
  email: '',
  /**
   * Social links. Paste your own profile URLs into `href`.
   * Entries with an empty href show as inactive placeholders.
   */
  socials: [
    { id: 'instagram', label: 'Instagram', href: '' },
    { id: 'youtube', label: 'YouTube', href: '' },
    { id: 'linkedin', label: 'LinkedIn', href: '' },
    { id: 'github', label: 'GitHub', href: '' },
  ] as { id: 'instagram' | 'youtube' | 'linkedin' | 'github'; label: string; href: string }[],
  about: [
    'I’m a multidisciplinary digital creator who blends motion, code and identity design into one consistent brand experience.',
    'Whether it’s an edit that holds attention, a website that feels effortless, or a mark people remember, the goal is always the same: clarity with a spark.',
  ],
}

export type ServiceIcon = 'video' | 'web' | 'brand' | 'social'

export interface Service {
  id: string
  icon: ServiceIcon
  title: string
  description: string
  points: string[]
  /** Accent gradient (CSS colors). */
  from: string
  to: string
}

export const services: Service[] = [
  {
    id: 'video',
    icon: 'video',
    title: 'Video Editing',
    description: 'Cuts, color and pacing that keep people watching, from short-form reels to brand films.',
    points: ['Reels & Shorts', 'Brand films', 'Motion titles'],
    from: '#ec4899',
    to: '#8b5cf6',
  },
  {
    id: 'web',
    icon: 'web',
    title: 'Web Development',
    description: 'Fast, responsive websites with thoughtful interaction, built to look sharp on every screen.',
    points: ['Landing pages', 'Portfolios', 'Web apps'],
    from: '#3b6bff',
    to: '#22d3ee',
  },
  {
    id: 'brand',
    icon: 'brand',
    title: 'Logo & Brand Design',
    description: 'Memorable marks and visual systems that make your brand instantly recognisable.',
    points: ['Logo design', 'Color & type', 'Brand guidelines'],
    from: '#8b5cf6',
    to: '#3b6bff',
  },
  {
    id: 'social',
    icon: 'social',
    title: 'Social Media Management',
    description: 'Consistent, on-brand content and community care that grows your audience steadily.',
    points: ['Content planning', 'Post design', 'Community'],
    from: '#22d3ee',
    to: '#ec4899',
  },
]

export type ProjectKind = 'video' | 'web' | 'logo' | 'social'

export interface Project {
  id: string
  title: string
  category: string
  kind: ProjectKind
  blurb: string
  tags: string[]
  /** Accent gradient used by the generated artwork. */
  from: string
  to: string
  /**
   * OPTIONAL: replace the generated artwork with a real image.
   * Put the file in /public/projects and use WebP or AVIF for the smallest size.
   * Example: { src: '/projects/my-work.webp', alt: 'My work', width: 1200, height: 900 }
   */
  image?: { src: string; alt: string; width: number; height: number }
  /** OPTIONAL: link to the real project (case study, video, live site). */
  href?: string
}

/** Every project below is a DEMONSTRATION placeholder. Replace with your real work. */
export const projects: Project[] = [
  {
    id: 'neon-drift',
    title: 'Neon Drift',
    category: 'Video Editing',
    kind: 'video',
    blurb: 'A fast-paced brand film with kinetic cuts and a bold color grade.',
    tags: ['Editing', 'Color', 'Motion'],
    from: '#ec4899',
    to: '#6d28d9',
  },
  {
    id: 'aurora-studio',
    title: 'Aurora Studio',
    category: 'Website Design',
    kind: 'web',
    blurb: 'A responsive marketing site with smooth motion and a clean design system.',
    tags: ['React', 'UI/UX', 'Responsive'],
    from: '#2563eb',
    to: '#22d3ee',
  },
  {
    id: 'orbit',
    title: 'Orbit',
    category: 'Logo Design',
    kind: 'logo',
    blurb: 'A minimal mark, color palette and usage guidelines for a young brand.',
    tags: ['Logo', 'Identity', 'Guidelines'],
    from: '#8b5cf6',
    to: '#3b6bff',
  },
  {
    id: 'pulse-launch',
    title: 'Pulse Launch',
    category: 'Social Media',
    kind: 'social',
    blurb: 'A content system for a product launch: reels, carousels and stories.',
    tags: ['Campaign', 'Content', 'Design'],
    from: '#22d3ee',
    to: '#ec4899',
  },
  {
    id: 'lumen-store',
    title: 'Lumen Store',
    category: 'Website Design',
    kind: 'web',
    blurb: 'A fast storefront concept with a focused, distraction-free checkout flow.',
    tags: ['E-commerce', 'Performance', 'UI'],
    from: '#7c3aed',
    to: '#ec4899',
  },
  {
    id: 'afterglow',
    title: 'Afterglow',
    category: 'Video Editing',
    kind: 'video',
    blurb: 'Vertical short-form edits paced for retention on Reels and Shorts.',
    tags: ['Short-form', 'Captions', 'Sound'],
    from: '#0ea5e9',
    to: '#8b5cf6',
  },
]
