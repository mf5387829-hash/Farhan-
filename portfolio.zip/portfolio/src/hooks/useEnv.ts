import { useSyncExternalStore } from 'react'

/** Subscribe to a CSS media query without re-rendering on every scroll/frame. */
export function useMediaQuery(query: string): boolean {
  return useSyncExternalStore(
    (onChange) => {
      const mql = window.matchMedia(query)
      mql.addEventListener('change', onChange)
      return () => mql.removeEventListener('change', onChange)
    },
    () => window.matchMedia(query).matches,
    () => false,
  )
}

export const useReducedMotion = () => useMediaQuery('(prefers-reduced-motion: reduce)')

/** True only for devices with a real mouse/trackpad (not phones or tablets). */
export const useFinePointer = () => useMediaQuery('(hover: hover) and (pointer: fine)')
