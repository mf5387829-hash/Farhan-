/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#05060a',
        electric: '#3b6bff',
        violet: '#8b5cf6',
        aqua: '#22d3ee',
        blush: '#ec4899',
      },
      fontFamily: {
        sans: ['"Sora Variable"', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translate3d(0, 0, 0)' },
          '50%': { transform: 'translate3d(0, -12px, 0)' },
        },
        'float-alt': {
          '0%, 100%': { transform: 'translate3d(0, 0, 0)' },
          '50%': { transform: 'translate3d(0, 10px, 0)' },
        },
        'spin-slower': {
          to: { transform: 'rotate(360deg)' },
        },
        'pulse-dot': {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '.45', transform: 'scale(.8)' },
        },
        'cue-bob': {
          '0%, 100%': { transform: 'translate3d(0, 0, 0)' },
          '50%': { transform: 'translate3d(0, 6px, 0)' },
        },
      },
      animation: {
        float: 'float 8s ease-in-out infinite',
        'float-alt': 'float-alt 9s ease-in-out infinite',
        'spin-slower': 'spin-slower 40s linear infinite',
        'pulse-dot': 'pulse-dot 2.4s ease-in-out infinite',
        'cue-bob': 'cue-bob 2.2s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
