import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base './' keeps asset URLs relative, so the build works on any host
// or sub-path (Netlify, Vercel, Cloudflare Pages, GitHub Pages...).
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    target: 'es2020',
    chunkSizeWarningLimit: 700,
    rollupOptions: {
      output: {
        // The 3D library only loads when the hero scene is mounted (lazy),
        // so it never blocks first paint.
        manualChunks: {
          three: ['three'],
          motion: ['framer-motion'],
        },
      },
    },
  },
})
